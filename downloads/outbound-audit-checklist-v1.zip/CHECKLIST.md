# 15-Minute Outbound Audit (Free Lead Magnet)

Use this before you buy any tool or hire a closer.

## Score yourself (0–2 each)
| Item | Score |
|------|-------|
| Offer fits in one sentence under 22 words | |
| Clear ICP (title + company size + trigger) | |
| 40+ named targets this month | |
| Personalized first line (not mail-merge fluff) | |
| 5-touch follow-up exists | |
| Discovery call has a script | |
| Proposal can go out same day | |
| Weekly scoreboard (sends → replies → calls → closes) | |
| **Total / 16** | |

## Read
- 0–7: Fix positioning + list before spending on ads
- 8–11: Install a sequence system (DIY pack or async install)
- 12–16: Add volume or a retainer operator

## Next step
If you want this built for your offer in 72 hours → Stackdraft Pipeline Install ($297).
Order: email jannas@7sense.net subject `ORDER STACKDRAFT INSTALL 297`
